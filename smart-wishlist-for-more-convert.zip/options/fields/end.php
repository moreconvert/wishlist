<?php
/**
 * Template for displaying the End Article
 *
 * @author MoreConvert
 * @package MoreConvert Options plugin
 * @version 1.1.0
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</tbody>
</table>
</div>
<table class="form-table" role="presentation">
	<tbody>
