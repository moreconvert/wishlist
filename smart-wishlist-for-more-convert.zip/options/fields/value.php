<?php
/**
 * Template for displaying the Title Field
 *
 * @author MoreConvert
 * @package MoreConvert Options plugin
 * @version 1.1.0
 * @since 1.1.0
 */

/**
 * Template variables:
 *
 * @var $name                      string Field name
 * @var $class                     string Field class
 * @var $field_id                  string Field Id
 * @var $value                     string Field value
 * @var $value_format              string Field Value format
 * @var $data                      string Data attributes
 * @var $custom_attributes         string Custom attributes
 * @var $dependies                 string Dependencies
 * @var $desc                      string Description
 * @var $field                     array Array of all field attributes
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<?php if ( isset( $value ) ) : ?>
	<?php echo isset($value_format) && '' !== $value ? wp_kses_post( sprintf($value_format , $value) ) : wp_kses_post( $value ); ?>
<?php endif; ?>
